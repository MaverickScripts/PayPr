"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ArrowRight, Shield, Zap, Brain, Menu, X } from "lucide-react"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"

export function LandingPage() {
  const [mounted, setMounted] = useState(false)
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    setMounted(true)

    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }

    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [])

  if (!mounted) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900/30 to-black dark:from-black dark:via-blue-950/40 dark:to-black relative overflow-hidden">
      {/* Dynamic background with mouse interaction - hidden on mobile for performance */}
      <div
        className="absolute inset-0 opacity-30 hidden md:block"
        style={{
          background: `radial-gradient(600px circle at ${mousePosition.x}px ${mousePosition.y}px, rgba(139, 92, 246, 0.15), transparent 40%)`,
        }}
      />

      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-20 -right-20 md:-top-40 md:-right-40 w-40 h-40 md:w-80 md:h-80 bg-gradient-to-r from-blue-500/10 to-indigo-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-20 -left-20 md:-bottom-40 md:-left-40 w-40 h-40 md:w-80 md:h-80 bg-gradient-to-r from-indigo-500/10 to-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-48 h-48 md:w-96 md:h-96 bg-gradient-to-r from-blue-500/5 to-indigo-500/5 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Floating particles - reduced on mobile */}
      <div className="absolute inset-0">
        {[...Array(window.innerWidth > 768 ? 20 : 8)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-blue-400/30 rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${3 + Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-slate-800/50 dark:border-slate-700/50 bg-slate-900/80 dark:bg-black/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4 md:py-6">
            <div className="flex items-center group cursor-pointer">
              <div className="relative">
                {/* Responsive Logo */}
                <div className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-700 rounded-xl md:rounded-2xl flex items-center justify-center mr-2 sm:mr-3 group-hover:scale-110 transition-all duration-300 shadow-lg shadow-blue-500/25 relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-xl md:rounded-2xl"></div>
                  <div className="absolute top-0.5 left-0.5 md:top-1 md:left-1 w-1 h-1 md:w-2 md:h-2 bg-white/30 rounded-full"></div>
                  <div className="absolute bottom-0.5 right-0.5 md:bottom-1 md:right-1 w-0.5 h-0.5 md:w-1 md:h-1 bg-white/20 rounded-full"></div>

                  <div className="relative z-10 flex items-center justify-center">
                    <svg width="16" height="16" className="sm:w-5 sm:h-5 md:w-6 md:h-6" viewBox="0 0 24 24" fill="none">
                      <path
                        d="M6 4h6c3.314 0 6 2.686 6 6s-2.686 6-6 6H8v4H6V4z"
                        fill="currentColor"
                        className="opacity-90 text-white"
                      />
                      <path d="M8 6v8h4c2.209 0 4-1.791 4-4s-1.791-4-4-4H8z" fill="rgba(255,255,255,0.3)" />
                      <path d="M18 10h2v4h-2z" fill="currentColor" className="opacity-60 text-white" />
                    </svg>
                  </div>
                </div>
                <div className="absolute -top-0.5 -right-0.5 md:-top-1 md:-right-1 w-2 h-2 md:w-4 md:h-4 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full animate-ping opacity-75"></div>
              </div>
              <span className="text-lg sm:text-xl md:text-2xl font-black bg-gradient-to-r from-white via-blue-200 to-indigo-200 bg-clip-text text-transparent">
                PayPr
              </span>
            </div>

            {/* Mobile menu button */}
            <div className="flex items-center space-x-2 md:space-x-4">
              <ThemeToggle />
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 rounded-lg bg-slate-800/50 text-white hover:bg-slate-700/50 transition-colors"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden border-t border-slate-800/50 py-4 space-y-2">
              <Link href="/dashboard" className="block">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-white hover:bg-slate-800/50"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Dashboard
                </Button>
              </Link>
              <Link href="/about" className="block">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-white hover:bg-slate-800/50"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  About
                </Button>
              </Link>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative z-10 py-12 sm:py-16 md:py-20 lg:py-32 flex items-center justify-center min-h-[calc(100vh-80px)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            {/* Animated logo - responsive sizing */}
            <div className="mb-8 sm:mb-10 md:mb-12 relative">
              <div className="relative inline-block">
                <div className="w-20 h-20 sm:w-24 sm:h-24 md:w-32 md:h-32 bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-700 rounded-2xl sm:rounded-3xl flex items-center justify-center mx-auto shadow-2xl shadow-blue-500/25 animate-float group hover:scale-110 transition-all duration-500 relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-2xl sm:rounded-3xl"></div>
                  <div className="absolute top-1 left-1 sm:top-2 sm:left-2 w-2 h-2 sm:w-3 sm:h-3 md:w-4 md:h-4 bg-white/30 rounded-full"></div>
                  <div className="absolute bottom-1 right-1 sm:bottom-2 sm:right-2 w-1 h-1 sm:w-2 sm:h-2 bg-white/20 rounded-full"></div>
                  <div className="absolute top-1/2 right-1 sm:right-2 w-0.5 h-0.5 sm:w-1 sm:h-1 bg-white/40 rounded-full"></div>

                  <div className="relative z-10 flex items-center justify-center">
                    <svg
                      width="32"
                      height="32"
                      className="sm:w-10 sm:h-10 md:w-12 md:h-12"
                      viewBox="0 0 24 24"
                      fill="none"
                    >
                      <path
                        d="M6 4h6c3.314 0 6 2.686 6 6s-2.686 6-6 6H8v4H6V4z"
                        fill="currentColor"
                        className="opacity-90 text-white"
                      />
                      <path d="M8 6v8h4c2.209 0 4-1.791 4-4s-1.791-4-4-4H8z" fill="rgba(255,255,255,0.3)" />
                      <path d="M18 10h2v4h-2z" fill="currentColor" className="opacity-60 text-white" />
                    </svg>
                  </div>
                </div>
                <div className="absolute -top-1 -right-1 sm:-top-2 sm:-right-2 w-4 h-4 sm:w-6 sm:h-6 md:w-8 md:h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full animate-ping"></div>
                <div className="absolute -bottom-1 -left-1 sm:-bottom-2 sm:-left-2 w-3 h-3 sm:w-4 sm:h-4 md:w-6 md:h-6 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full animate-pulse"></div>
              </div>
            </div>

            <div className="space-y-4 sm:space-y-6 md:space-y-8 mb-8 sm:mb-10 md:mb-12">
              <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-black mb-4 sm:mb-6 animate-fade-in">
                <span className="bg-gradient-to-r from-white via-blue-200 to-indigo-200 bg-clip-text text-transparent block">
                  Money
                </span>
                <span className="bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-500 bg-clip-text text-transparent block">
                  Moves
                </span>
              </h1>

              <p className="text-lg sm:text-xl md:text-2xl text-slate-300 mb-6 sm:mb-8 max-w-4xl mx-auto leading-relaxed animate-fade-in-delay px-4">
                Your AI-powered financial sidekick that actually gets it.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center mb-12 sm:mb-14 md:mb-16 animate-fade-in-delay-2 px-4">
              <Link href="/dashboard">
                <Button
                  size="lg"
                  className="w-full sm:w-auto bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:via-indigo-700 hover:to-purple-700 text-white px-6 sm:px-8 md:px-10 py-3 sm:py-4 text-lg sm:text-xl font-bold rounded-xl sm:rounded-2xl shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300 hover:scale-105 group border-0"
                >
                  Start Tracking
                  <ArrowRight className="ml-2 sm:ml-3 w-5 h-5 sm:w-6 sm:h-6 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Link href="/about">
                <Button
                  variant="outline"
                  size="lg"
                  className="w-full sm:w-auto px-6 sm:px-8 md:px-10 py-3 sm:py-4 text-lg sm:text-xl font-bold rounded-xl sm:rounded-2xl border-2 border-slate-700 hover:border-blue-500 bg-slate-800/50 hover:bg-slate-700/50 text-white transition-all duration-300 backdrop-blur-sm"
                >
                  Learn More
                </Button>
              </Link>
            </div>

            {/* Trust indicators with animations */}
            <div className="flex flex-wrap justify-center items-center gap-4 sm:gap-6 md:gap-8 text-sm sm:text-base text-slate-400 animate-fade-in-delay-3 px-4">
              <div className="flex items-center space-x-2 group">
                <Shield className="w-4 h-4 sm:w-5 sm:h-5 group-hover:text-blue-400 transition-colors" />
                <span className="group-hover:text-slate-300 transition-colors">Privacy First</span>
              </div>
              <div className="flex items-center space-x-2 group">
                <Zap className="w-4 h-4 sm:w-5 sm:h-5 group-hover:text-blue-400 transition-colors" />
                <span className="group-hover:text-slate-300 transition-colors">No Setup</span>
              </div>
              <div className="flex items-center space-x-2 group">
                <Brain className="w-4 h-4 sm:w-5 sm:h-5 group-hover:text-blue-400 transition-colors" />
                <span className="group-hover:text-slate-300 transition-colors">AI-Powered</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
