"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Plus, TrendingUp, Filter, ArrowLeft, Target, Zap, Menu, X } from "lucide-react"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"
import { AddExpenseModal } from "@/components/add-expense-modal"
import { ExpenseList } from "@/components/expense-list"
import { SpendingAlert } from "@/components/spending-alert"
import { AbnormalSpendingAlert } from "@/components/abnormal-spending-alert"
import { WelcomeModal } from "@/components/welcome-modal"
import { MonthlyResetModal } from "@/components/monthly-reset-modal"

interface Expense {
  id: string
  amount: number
  category: string
  description: string
  date: string
  currency: string
}

interface UserData {
  name: string
  monthlyBudget: number
  savingsGoal: number
}

export function Dashboard() {
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [userData, setUserData] = useState<UserData>({ name: "", monthlyBudget: 2000, savingsGoal: 500 })
  const [currency, setCurrency] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("paypr-currency") || "$"
    }
    return "$"
  })
  const [showWelcome, setShowWelcome] = useState(false)
  const [showSpendingAlert, setShowSpendingAlert] = useState(false)
  const [showAbnormalAlert, setShowAbnormalAlert] = useState(false)
  const [abnormalSpending, setAbnormalSpending] = useState<{
    category: string
    currentAmount: number
    avgAmount: number
    description: string
  } | null>(null)
  const [showMonthlyReset, setShowMonthlyReset] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    // Check if user is new
    const hasVisited = localStorage.getItem("paypr-visited")
    if (!hasVisited) {
      setShowWelcome(true)
    } else {
      // Load user data
      const savedUserData = localStorage.getItem("paypr-user-data")
      if (savedUserData) {
        setUserData(JSON.parse(savedUserData))
      }
    }
    fetchExpenses()
  }, [])

  useEffect(() => {
    localStorage.setItem("paypr-currency", currency)
  }, [currency])

  useEffect(() => {
    const totalSpent = expenses.reduce((sum, expense) => sum + expense.amount, 0)
    const budgetProgress = (totalSpent / userData.monthlyBudget) * 100

    if (budgetProgress >= 85 && budgetProgress < 100) {
      setShowSpendingAlert(true)
    }

    checkAbnormalSpending()
  }, [expenses, userData.monthlyBudget])

  useEffect(() => {
    checkMonthlyReset()
  }, [])

  const handleWelcomeComplete = (newUserData: UserData) => {
    setUserData(newUserData)
    localStorage.setItem("paypr-visited", "true")
    localStorage.setItem("paypr-user-data", JSON.stringify(newUserData))
    setShowWelcome(false)
  }

  const fetchExpenses = async () => {
    try {
      const response = await fetch("/api/expenses")
      const data = await response.json()
      setExpenses(data)
    } catch (error) {
      console.error("Failed to fetch expenses:", error)
    }
  }

  const checkAbnormalSpending = () => {
    if (expenses.length < 5) return

    const categoryTotals = expenses.reduce(
      (acc, expense) => {
        acc[expense.category] = (acc[expense.category] || 0) + expense.amount
        return acc
      },
      {} as Record<string, number>,
    )

    const userAverages: Record<string, number> = {}
    const categoryCounts: Record<string, number> = {}

    expenses.forEach((expense) => {
      if (!userAverages[expense.category]) {
        userAverages[expense.category] = 0
        categoryCounts[expense.category] = 0
      }
      userAverages[expense.category] += expense.amount
      categoryCounts[expense.category]++
    })

    Object.keys(userAverages).forEach((category) => {
      userAverages[category] = userAverages[category] / categoryCounts[category]
    })

    const recentExpenses = expenses.slice(0, 3)
    for (const expense of recentExpenses) {
      const avgForCategory = userAverages[expense.category] || 50
      if (expense.amount > avgForCategory * 3 && expense.amount > 100) {
        setAbnormalSpending({
          category: expense.category,
          currentAmount: expense.amount,
          avgAmount: avgForCategory,
          description: `This ${expense.category.toLowerCase()} expense (${currency}${expense.amount}) is much higher than your usual ${currency}${avgForCategory.toFixed(2)} average`,
        })
        setShowAbnormalAlert(true)
        break
      }
    }
  }

  const checkMonthlyReset = () => {
    const lastResetMonth = localStorage.getItem("paypr-last-reset")
    const currentMonth = new Date().getMonth()
    const currentYear = new Date().getFullYear()
    const currentMonthYear = `${currentYear}-${currentMonth}`

    if (lastResetMonth !== currentMonthYear && lastResetMonth !== null) {
      setShowMonthlyReset(true)
    } else if (lastResetMonth === null) {
      localStorage.setItem("paypr-last-reset", currentMonthYear)
    }
  }

  const handleMonthlyReset = async (newBudgetData: { monthlyBudget: number; savingsGoal: number }) => {
    const updatedUserData = { ...userData, ...newBudgetData }
    setUserData(updatedUserData)
    localStorage.setItem("paypr-user-data", JSON.stringify(updatedUserData))

    const currentMonth = new Date().getMonth()
    const currentYear = new Date().getFullYear()
    const currentMonthYear = `${currentYear}-${currentMonth}`
    localStorage.setItem("paypr-last-reset", currentMonthYear)

    await fetch("/api/expenses/reset", { method: "POST" })
    setExpenses([])
    setShowMonthlyReset(false)
  }

  const totalSpent = expenses.reduce((sum, expense) => sum + expense.amount, 0)
  const budgetProgress = (totalSpent / userData.monthlyBudget) * 100
  const remainingBudget = userData.monthlyBudget - totalSpent
  const savingsProgress = (Math.max(0, remainingBudget) / userData.savingsGoal) * 100

  const categoryTotals = expenses.reduce(
    (acc, expense) => {
      acc[expense.category] = (acc[expense.category] || 0) + expense.amount
      return acc
    },
    {} as Record<string, number>,
  )

  const topCategories =
    expenses.length > 0
      ? Object.entries(categoryTotals)
          .sort(([, a], [, b]) => b - a)
          .slice(0, 4)
      : []

  const handleAddExpense = async (expense: Omit<Expense, "id" | "date">) => {
    try {
      const response = await fetch("/api/expenses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(expense),
      })
      const newExpense = await response.json()
      setExpenses((prev) => [newExpense, ...prev])
      setIsAddModalOpen(false)
    } catch (error) {
      console.error("Failed to add expense:", error)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900/20 to-black dark:from-black dark:via-blue-950/30 dark:to-black">
      {/* Header */}
      <header className="bg-slate-900/80 dark:bg-black/80 backdrop-blur-xl border-b border-slate-800/50 dark:border-slate-700/50 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-3 sm:py-4">
            <div className="flex items-center space-x-2 sm:space-x-4 min-w-0 flex-1">
              <Link href="/" className="hidden sm:block">
                <Button
                  variant="ghost"
                  size="sm"
                  className="hover:bg-slate-800 dark:hover:bg-slate-800 text-slate-300 hover:text-white"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
              </Link>

              <div className="flex items-center min-w-0 flex-1">
                {/* Responsive Logo */}
                <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-700 rounded-lg sm:rounded-xl flex items-center justify-center mr-2 sm:mr-3 shadow-lg shadow-blue-500/25 relative overflow-hidden flex-shrink-0">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-lg sm:rounded-xl"></div>
                  <div className="absolute top-0.5 left-0.5 sm:top-1 sm:left-1 w-1 h-1 sm:w-1.5 sm:h-1.5 bg-white/30 rounded-full"></div>
                  <div className="absolute bottom-0.5 right-0.5 sm:bottom-1 sm:right-1 w-0.5 h-0.5 sm:w-1 sm:h-1 bg-white/20 rounded-full"></div>

                  <div className="relative z-10 flex items-center justify-center">
                    <svg width="16" height="16" className="sm:w-5 sm:h-5" viewBox="0 0 24 24" fill="none">
                      <path
                        d="M6 4h6c3.314 0 6 2.686 6 6s-2.686 6-6 6H8v4H6V4z"
                        fill="currentColor"
                        className="opacity-90 text-white"
                      />
                      <path d="M8 6v8h4c2.209 0 4-1.791 4-4s-1.791-4-4-4H8z" fill="rgba(255,255,255,0.3)" />
                      <path d="M18 10h2v4h-2z" fill="currentColor" className="opacity-60 text-white" />
                    </svg>
                  </div>
                </div>
                <div className="min-w-0 flex-1">
                  <h1 className="text-base sm:text-lg md:text-xl font-bold text-white truncate">
                    What's good, {userData.name || "User"}? 👋
                  </h1>
                  <p className="text-xs sm:text-sm text-slate-400 hidden sm:block">
                    {new Date().toLocaleDateString("en-US", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-2 sm:space-x-4 flex-shrink-0">
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="px-2 py-1 sm:px-3 sm:py-2 border border-slate-700 rounded-lg sm:rounded-xl bg-slate-800/80 dark:bg-slate-900/80 text-white text-xs sm:text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent backdrop-blur-sm"
              >
                <option value="$">USD ($)</option>
                <option value="₹">INR (₹)</option>
                <option value="€">EUR (€)</option>
                <option value="£">GBP (£)</option>
              </select>
              <ThemeToggle />

              {/* Mobile menu button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="sm:hidden p-2 rounded-lg bg-slate-800/50 text-white hover:bg-slate-700/50 transition-colors"
              >
                {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation Menu */}
          {mobileMenuOpen && (
            <div className="sm:hidden border-t border-slate-800/50 py-4 space-y-2">
              <Link href="/" className="block">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-white hover:bg-slate-800/50"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Home
                </Button>
              </Link>
              <Link href="/reports" className="block">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-white hover:bg-slate-800/50"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <TrendingUp className="w-4 h-4 mr-2" />
                  View Reports
                </Button>
              </Link>
              <Link href="/about" className="block">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-white hover:bg-slate-800/50"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <Zap className="w-4 h-4 mr-2" />
                  About PayPr
                </Button>
              </Link>
            </div>
          )}
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 md:py-8">
        {/* Overview Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6 mb-6 sm:mb-8">
          {/* Budget Card */}
          <Card className="lg:col-span-2 bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-[1.02]">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-base sm:text-lg font-bold text-white">Monthly Budget</CardTitle>
              <Badge className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-0 text-xs sm:text-sm">
                {new Date().toLocaleDateString("en-US", { month: "long", year: "numeric" })}
              </Badge>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 sm:space-y-4">
                <div className="flex items-baseline space-x-2">
                  <span className="text-2xl sm:text-3xl md:text-4xl font-black text-white">
                    {currency}
                    {totalSpent.toFixed(2)}
                  </span>
                  <span className="text-sm sm:text-base md:text-lg text-slate-400">
                    of {currency}
                    {userData.monthlyBudget}
                  </span>
                </div>
                <Progress value={budgetProgress} className="h-2 sm:h-3 bg-slate-700" />
                <div className="flex justify-between text-xs sm:text-sm text-slate-400">
                  <span className="font-medium">{budgetProgress.toFixed(1)}% used</span>
                  <span className="font-medium">
                    {currency}
                    {remainingBudget.toFixed(2)} remaining
                  </span>
                </div>
                {budgetProgress > 85 && (
                  <div className="bg-orange-900/30 border border-orange-700/50 rounded-xl p-3">
                    <p className="text-xs sm:text-sm text-orange-300 font-medium">
                      ⚠️ You're approaching your monthly budget limit
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Savings Goal Card */}
          <Card className="bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-[1.02]">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-base sm:text-lg font-bold text-white">Potential Savings</CardTitle>
              <Target className="h-4 w-4 sm:h-5 sm:w-5 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="space-y-3 sm:space-y-4">
                <div className="text-2xl sm:text-3xl md:text-4xl font-black text-white">
                  {currency}
                  {Math.max(0, remainingBudget).toFixed(2)}
                </div>
                <Progress value={Math.min(100, savingsProgress)} className="h-2 sm:h-3 bg-slate-700" />
                <div className="text-xs sm:text-sm text-slate-400">
                  <span className="font-medium">{Math.min(100, savingsProgress).toFixed(1)}%</span> of {currency}
                  {userData.savingsGoal} monthly goal
                </div>
                <p className="text-xs text-slate-500">Money left from your budget that you can save</p>
                {savingsProgress >= 100 && (
                  <div className="bg-green-900/30 border border-green-700/50 rounded-xl p-3">
                    <p className="text-xs sm:text-sm text-green-300 font-medium">🎉 Savings goal achieved!</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Category Overview */}
        {topCategories.length > 0 && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6 mb-6 sm:mb-8">
            {topCategories.map(([category, amount]) => (
              <Card
                key={category}
                className="bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 group"
              >
                <CardContent className="p-3 sm:p-4 md:p-6">
                  <div className="flex items-center justify-between">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs sm:text-sm font-medium text-slate-400 truncate">{category}</p>
                      <p className="text-lg sm:text-xl md:text-2xl font-bold text-white">
                        {currency}
                        {amount.toFixed(2)}
                      </p>
                    </div>
                    <div className="text-xl sm:text-2xl md:text-3xl group-hover:scale-110 transition-transform duration-300 flex-shrink-0 ml-2">
                      {category === "Food" && "🍕"}
                      {category === "Shopping" && "🛍️"}
                      {category === "Subscriptions" && "📱"}
                      {category === "Transport" && "🚗"}
                      {category === "Entertainment" && "🎬"}
                      {category === "Health" && "🏥"}
                      {category === "Education" && "📚"}
                      {![
                        "Food",
                        "Shopping",
                        "Subscriptions",
                        "Transport",
                        "Entertainment",
                        "Health",
                        "Education",
                      ].includes(category) && "💰"}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Actions - Hidden on mobile, replaced by FAB */}
        <div className="hidden sm:flex flex-col sm:flex-row gap-4 mb-6 sm:mb-8">
          <Button
            onClick={() => setIsAddModalOpen(true)}
            className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:via-indigo-700 hover:to-purple-700 text-white shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300 hover:scale-105 border-0 font-bold"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Expense
          </Button>
          <Link href="/reports">
            <Button
              variant="outline"
              className="bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm hover:bg-slate-700/50 border-slate-700 text-white hover:text-white font-bold"
            >
              <TrendingUp className="w-4 h-4 mr-2" />
              View Reports
            </Button>
          </Link>
          <Link href="/about">
            <Button
              variant="outline"
              className="bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm hover:bg-slate-700/50 border-slate-700 text-white hover:text-white font-bold"
            >
              <Zap className="w-4 h-4 mr-2" />
              About PayPr
            </Button>
          </Link>
        </div>

        {/* Recent Expenses */}
        <Card className="bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 shadow-xl">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg sm:text-xl font-bold text-white">Recent Expenses</CardTitle>
              <Button variant="ghost" size="sm" className="hover:bg-slate-700 text-slate-400 hover:text-white">
                <Filter className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <ExpenseList expenses={expenses} currency={currency} />
          </CardContent>
        </Card>
      </div>

      {/* Mobile FAB */}
      <Button
        onClick={() => setIsAddModalOpen(true)}
        className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:via-indigo-700 hover:to-purple-700 shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300 hover:scale-110 sm:hidden z-50 border-0"
      >
        <Plus className="w-6 h-6 sm:w-8 sm:h-8" />
      </Button>

      {/* Modals */}
      <WelcomeModal isOpen={showWelcome} onClose={handleWelcomeComplete} />

      <AddExpenseModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAdd={handleAddExpense}
        currency={currency}
      />

      <SpendingAlert
        isOpen={showSpendingAlert}
        onClose={() => setShowSpendingAlert(false)}
        budgetProgress={budgetProgress}
        remainingAmount={remainingBudget}
        currency={currency}
      />

      {abnormalSpending && (
        <AbnormalSpendingAlert
          isOpen={showAbnormalAlert}
          onClose={() => setShowAbnormalAlert(false)}
          spendingData={abnormalSpending}
          currency={currency}
        />
      )}
      <MonthlyResetModal isOpen={showMonthlyReset} onClose={handleMonthlyReset} currentUserData={userData} />
    </div>
  )
}
