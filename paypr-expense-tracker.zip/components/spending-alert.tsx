"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { AlertTriangle } from "lucide-react"

interface SpendingAlertProps {
  isOpen: boolean
  onClose: () => void
  budgetProgress: number
  remainingAmount: number
  currency: string
}

export function SpendingAlert({ isOpen, onClose, budgetProgress, remainingAmount, currency }: SpendingAlertProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-orange-500" />
            <span>Budget Alert</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="text-center">
            <div className="text-4xl mb-2">⚠️</div>
            <h3 className="text-lg font-semibold mb-2">You're near your monthly limit!</h3>
            <p className="text-gray-600 dark:text-gray-300">
              You've used <span className="font-bold">{budgetProgress.toFixed(1)}%</span> of your monthly budget.
            </p>
            <p className="text-lg font-semibold mt-2">
              Only {currency}
              {remainingAmount.toFixed(2)} remaining this month.
            </p>
          </div>

          <div className="bg-orange-50 dark:bg-orange-900/20 rounded-lg p-4">
            <h4 className="font-semibold mb-2">Quick Tips:</h4>
            <ul className="text-sm space-y-1">
              <li>• Review your recent expenses</li>
              <li>• Consider postponing non-essential purchases</li>
              <li>• Check if you can optimize any subscriptions</li>
            </ul>
          </div>

          <Button onClick={onClose} className="w-full">
            Got it, thanks!
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
