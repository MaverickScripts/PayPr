"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Github, Linkedin, Mail, Send, Smartphone, Monitor, Menu, X } from "lucide-react"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"

export function AboutPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    role: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [deviceType, setDeviceType] = useState<"mobile" | "desktop">("desktop")
  const [emailMethod, setEmailMethod] = useState<"gmail" | "native" | "fallback">("gmail")
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const detectDevice = () => {
      const userAgent = navigator.userAgent.toLowerCase()
      const isMobile = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(userAgent)
      const isTablet = /ipad|android(?!.*mobile)/i.test(userAgent)
      const isTouchDevice = "ontouchstart" in window || navigator.maxTouchPoints > 0
      const isSmallScreen = window.innerWidth <= 768

      const isMobileDevice = isMobile || (isTouchDevice && isSmallScreen)

      setDeviceType(isMobileDevice ? "mobile" : "desktop")

      if (isMobileDevice) {
        setEmailMethod("native")
      } else {
        setEmailMethod("gmail")
      }
    }

    detectDevice()
    window.addEventListener("resize", detectDevice)
    return () => window.removeEventListener("resize", detectDevice)
  }, [])

  const openEmailClient = (method: "gmail" | "native" | "fallback") => {
    const subject = `PayPr Contact Form - Message from ${formData.name}`
    const body = `Hi PayPr Team,

I'm reaching out through your contact form with the following details:

Name: ${formData.name}
Email: ${formData.email}
Role: ${formData.role}

Message:
${formData.message}

---
Sent from PayPr Contact Form
Device: ${deviceType === "mobile" ? "Mobile" : "Desktop"}
${new Date().toLocaleDateString("en-US", {
  weekday: "long",
  year: "numeric",
  month: "long",
  day: "numeric",
  hour: "2-digit",
  minute: "2-digit",
})}`

    const encodedSubject = encodeURIComponent(subject)
    const encodedBody = encodeURIComponent(body)
    const email = "heypaypr@gmail.com"

    let emailUrl = ""
    let success = false

    try {
      switch (method) {
        case "native":
          emailUrl = `mailto:${email}?subject=${encodedSubject}&body=${encodedBody}`
          window.location.href = emailUrl
          success = true
          break

        case "gmail":
          emailUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${email}&su=${encodedSubject}&body=${encodedBody}`
          const gmailWindow = window.open(emailUrl, "_blank", "noopener,noreferrer")
          success = !!gmailWindow
          break

        case "fallback":
          const emailContent = `To: ${email}\nSubject: ${subject}\n\n${body.replace(/\n/g, "\n")}`
          navigator.clipboard
            .writeText(emailContent)
            .then(() => {
              success = true
            })
            .catch(() => {
              alert(`Please copy this email content:\n\nTo: ${email}\nSubject: ${subject}\n\n${body}`)
              success = true
            })
          break
      }
    } catch (error) {
      console.error("Email client error:", error)
      success = false
    }

    return success
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    let success = false

    if (deviceType === "mobile") {
      success = openEmailClient("native")

      if (!success) {
        setTimeout(() => {
          success = openEmailClient("gmail")
          if (!success) {
            openEmailClient("fallback")
            success = true
          }
        }, 1000)
      }
    } else {
      success = openEmailClient("gmail")

      if (!success) {
        setTimeout(() => {
          success = openEmailClient("native")
          if (!success) {
            openEmailClient("fallback")
            success = true
          }
        }, 1000)
      }
    }

    setSubmitted(true)
    setFormData({ name: "", email: "", role: "", message: "" })
    setIsSubmitting(false)

    setTimeout(() => {
      setSubmitted(false)
    }, 8000)
  }

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const getDeviceSpecificInstructions = () => {
    if (deviceType === "mobile") {
      return {
        icon: <Smartphone className="w-4 h-4 text-blue-400" />,
        title: "Mobile Email Setup",
        description:
          "We'll open your default email app with the message pre-filled. If that doesn't work, we'll try the Gmail app or copy the message for you to paste.",
      }
    } else {
      return {
        icon: <Monitor className="w-4 h-4 text-blue-400" />,
        title: "Desktop Email Setup",
        description:
          "We'll open Gmail in your browser with the message pre-filled. If Gmail doesn't open, we'll try your default email client or copy the message to your clipboard.",
      }
    }
  }

  const instructions = getDeviceSpecificInstructions()

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900/20 to-black dark:from-black dark:via-blue-950/30 dark:to-black">
      {/* Header */}
      <header className="bg-slate-900/80 dark:bg-black/80 backdrop-blur-xl border-b border-slate-800/50 dark:border-slate-700/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-3 sm:py-4">
            <div className="flex items-center space-x-2 sm:space-x-4">
              <Link href="/dashboard" className="hidden sm:block">
                <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white hover:bg-slate-800">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Dashboard
                </Button>
              </Link>
              <h1 className="text-lg sm:text-xl font-bold text-white">About PayPr</h1>
            </div>
            <div className="flex items-center space-x-2 sm:space-x-4">
              <ThemeToggle />

              {/* Mobile menu button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="sm:hidden p-2 rounded-lg bg-slate-800/50 text-white hover:bg-slate-700/50 transition-colors"
              >
                {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation Menu */}
          {mobileMenuOpen && (
            <div className="sm:hidden border-t border-slate-800/50 py-4 space-y-2">
              <Link href="/dashboard" className="block">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-white hover:bg-slate-800/50"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <Link href="/" className="block">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-white hover:bg-slate-800/50"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Home
                </Button>
              </Link>
            </div>
          )}
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 md:py-12">
        {/* About PayPr Section */}
        <div className="text-center mb-12 sm:mb-16">
          {/* Responsive Logo */}
          <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-700 rounded-2xl sm:rounded-3xl flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-lg shadow-blue-500/25 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-2xl sm:rounded-3xl"></div>
            <div className="absolute top-1 left-1 sm:top-2 sm:left-2 w-2 h-2 sm:w-3 sm:h-3 bg-white/30 rounded-full"></div>
            <div className="absolute bottom-1 right-1 sm:bottom-2 sm:right-2 w-1 h-1 sm:w-2 sm:h-2 bg-white/20 rounded-full"></div>
            <div className="absolute top-1/2 right-1 sm:right-2 w-0.5 h-0.5 sm:w-1 sm:h-1 bg-white/40 rounded-full"></div>

            <div className="relative z-10 flex items-center justify-center">
              <svg width="24" height="24" className="sm:w-8 sm:h-8" viewBox="0 0 24 24" fill="none">
                <path
                  d="M6 4h6c3.314 0 6 2.686 6 6s-2.686 6-6 6H8v4H6V4z"
                  fill="currentColor"
                  className="opacity-90 text-white"
                />
                <path d="M8 6v8h4c2.209 0 4-1.791 4-4s-1.791-4-4-4H8z" fill="rgba(255,255,255,0.3)" />
                <path d="M18 10h2v4h-2z" fill="currentColor" className="opacity-60 text-white" />
              </svg>
            </div>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white mb-4 sm:mb-6">About PayPr</h2>
          <p className="text-lg sm:text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
            PayPr helps you track expenses and manage your budget with smart AI insights. Simple, private, and
            effective.
          </p>
        </div>

        {/* Creator's Section */}
        <Card className="mb-8 sm:mb-12 bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl sm:text-3xl font-black text-center text-white">Creator's Section</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-700 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-lg shadow-blue-500/25">
              <span className="text-white font-black text-lg sm:text-xl md:text-2xl">SC</span>
            </div>
            <p className="text-base sm:text-lg text-slate-300 max-w-3xl mx-auto leading-relaxed mb-6 sm:mb-8">
              Hey, I'm <span className="font-bold text-blue-400">Shreyas Chowdhury</span> — a tech enthusiast who got
              tired of clunky finance apps and decided to build one that actually feels good to use. I made PayPr for
              people like me who want control over their money without sacrificing style, speed, or sanity.
            </p>

            <div className="flex flex-col sm:flex-row justify-center space-y-3 sm:space-y-0 sm:space-x-6">
              <a
                href="https://linkedin.com/in/shreyaschowdhury"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center space-x-2 px-4 sm:px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-xl font-bold"
              >
                <Linkedin className="w-5 h-5" />
                <span>LinkedIn</span>
              </a>
              <a
                href="https://github.com/MaverickScripts"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center space-x-2 px-4 sm:px-6 py-3 bg-gradient-to-r from-slate-700 to-slate-800 text-white rounded-xl hover:from-slate-800 hover:to-slate-900 transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-xl font-bold"
              >
                <Github className="w-5 h-5" />
                <span>GitHub</span>
              </a>
            </div>
          </CardContent>
        </Card>

        {/* Contact Form */}
        <Card className="bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-white">
              <Mail className="w-5 h-5" />
              <span>Get in Touch</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {submitted ? (
              <div className="text-center py-6 sm:py-8">
                <div className="text-4xl sm:text-6xl mb-4">{deviceType === "mobile" ? "📱" : "💻"}</div>
                <h3 className="text-xl sm:text-2xl font-bold text-white mb-2">
                  {deviceType === "mobile" ? "Email App Opened!" : "Email Client Opened!"}
                </h3>
                <p className="text-slate-300 mb-4 text-sm sm:text-base">
                  {deviceType === "mobile"
                    ? "Your email app should open with the message pre-filled. If it didn't work, the message has been copied to your clipboard."
                    : "Gmail or your default email client should open with the message pre-filled. If nothing opened, the message has been copied to your clipboard."}
                </p>
                <div className="bg-green-900/20 border border-green-700/50 rounded-xl p-4 mb-4">
                  <p className="text-xs sm:text-sm text-green-300">
                    <strong>To:</strong> heypaypr@gmail.com
                    <br />
                    <strong>Subject:</strong> PayPr Contact Form - Message from {formData.name || "User"}
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Button
                    onClick={() => setSubmitted(false)}
                    variant="outline"
                    className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-600/50"
                  >
                    Send Another Message
                  </Button>
                  <Button
                    onClick={() => openEmailClient("fallback")}
                    variant="outline"
                    className="bg-blue-900/30 border-blue-700/50 text-blue-300 hover:bg-blue-800/30"
                  >
                    Copy Message Again
                  </Button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
                <div className="bg-blue-900/20 border border-blue-700/50 rounded-xl p-3 sm:p-4 mb-4 sm:mb-6">
                  <div className="flex items-center space-x-2 mb-2">
                    {instructions.icon}
                    <span className="text-sm font-medium text-blue-300">{instructions.title}</span>
                    <div className="ml-auto">
                      <span className="text-xs bg-blue-800/50 text-blue-200 px-2 py-1 rounded-full">
                        {deviceType === "mobile" ? "Mobile Detected" : "Desktop Detected"}
                      </span>
                    </div>
                  </div>
                  <p className="text-xs sm:text-sm text-blue-200">{instructions.description}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Name</label>
                    <Input
                      value={formData.name}
                      onChange={(e) => handleChange("name", e.target.value)}
                      placeholder="Your name"
                      required
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Email</label>
                    <Input
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleChange("email", e.target.value)}
                      placeholder="your@email.com"
                      required
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Role</label>
                  <Select value={formData.role} onValueChange={(value) => handleChange("role", value)}>
                    <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white focus:ring-blue-500 focus:border-blue-500">
                      <SelectValue placeholder="Select your role" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-700">
                      <SelectItem value="user" className="text-white hover:bg-slate-700">
                        User
                      </SelectItem>
                      <SelectItem value="contributor" className="text-white hover:bg-slate-700">
                        Contributor
                      </SelectItem>
                      <SelectItem value="both" className="text-white hover:bg-slate-700">
                        Both
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Message</label>
                  <Textarea
                    value={formData.message}
                    onChange={(e) => handleChange("message", e.target.value)}
                    placeholder="Tell me what's on your mind..."
                    rows={4}
                    required
                    className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:via-indigo-700 hover:to-purple-700 shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300 border-0 font-bold"
                >
                  {isSubmitting ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>{deviceType === "mobile" ? "Opening Email App..." : "Opening Email Client..."}</span>
                    </div>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      {deviceType === "mobile" ? "Send via Email App" : "Send via Email Client"}
                    </>
                  )}
                </Button>

                <div className="text-center">
                  <p className="text-xs text-slate-500">
                    {deviceType === "mobile"
                      ? "This will open your default email app or copy the message to your clipboard"
                      : "This will open Gmail in your browser or your default email client"}{" "}
                    to send to <span className="text-blue-400 font-medium">heypaypr@gmail.com</span>
                  </p>
                </div>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
