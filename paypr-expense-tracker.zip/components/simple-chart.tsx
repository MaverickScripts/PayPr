"use client"

interface SimpleChartProps {
  data: Record<string, number>
  type: "pie" | "bar"
  currency?: string
}

const COLORS = ["#3B82F6", "#8B5CF6", "#10B981", "#F59E0B", "#EF4444", "#6B7280", "#EC4899", "#14B8A6"]

export function SimpleChart({ data, type, currency = "$" }: SimpleChartProps) {
  console.log("SimpleChart received data:", data, "type:", type)

  if (!data || typeof data !== "object") {
    return (
      <div className="h-[300px] flex items-center justify-center text-slate-500">
        <div className="text-center">
          <div className="text-4xl mb-2">📊</div>
          <p className="text-white">No data provided</p>
        </div>
      </div>
    )
  }

  const chartData = Object.entries(data)
    .filter(([, amount]) => amount > 0)
    .sort(([, a], [, b]) => b - a)

  if (chartData.length === 0) {
    return (
      <div className="h-[300px] flex items-center justify-center text-slate-500">
        <div className="text-center">
          <div className="text-4xl mb-2">📊</div>
          <p className="text-white">No data available</p>
          <p className="text-sm text-slate-400">Add some expenses to see charts</p>
        </div>
      </div>
    )
  }

  const total = chartData.reduce((sum, [, amount]) => sum + amount, 0)

  if (type === "pie") {
    return (
      <div className="h-[300px] flex items-center justify-center">
        <div className="relative w-64 h-64">
          {/* Simple CSS-based pie chart */}
          <div className="w-full h-full rounded-full relative overflow-hidden bg-slate-700">
            {chartData.map(([category, amount], index) => {
              const percentage = (amount / total) * 100
              const rotation = chartData.slice(0, index).reduce((acc, [, amt]) => acc + (amt / total) * 360, 0)

              return (
                <div
                  key={category}
                  className="absolute inset-0 rounded-full"
                  style={{
                    background: `conic-gradient(from ${rotation}deg, ${COLORS[index % COLORS.length]} 0deg, ${COLORS[index % COLORS.length]} ${percentage * 3.6}deg, transparent ${percentage * 3.6}deg)`,
                  }}
                />
              )
            })}

            {/* Center hole */}
            <div className="absolute inset-8 bg-slate-800 rounded-full flex items-center justify-center">
              <div className="text-center">
                <div className="text-lg font-bold text-white">
                  {currency}
                  {total.toFixed(0)}
                </div>
                <div className="text-xs text-slate-400">Total</div>
              </div>
            </div>
          </div>

          {/* Legend */}
          <div className="absolute -right-32 top-0 space-y-2">
            {chartData.slice(0, 6).map(([category, amount], index) => (
              <div key={category} className="flex items-center space-x-2 text-xs">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                <span className="text-white truncate max-w-20">{category}</span>
                <span className="text-slate-400">
                  {currency}
                  {amount.toFixed(0)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  // Simple bar chart
  const maxAmount = Math.max(...chartData.map(([, amount]) => amount))

  return (
    <div className="h-[300px] p-4">
      <div className="h-full flex items-end space-x-2">
        {chartData.slice(0, 8).map(([category, amount], index) => {
          const height = (amount / maxAmount) * 100
          return (
            <div key={category} className="flex-1 flex flex-col items-center">
              <div className="text-xs text-white mb-1 font-medium">
                {currency}
                {amount.toFixed(0)}
              </div>
              <div
                className="w-full rounded-t-lg transition-all duration-500 hover:opacity-80"
                style={{
                  height: `${height}%`,
                  backgroundColor: COLORS[index % COLORS.length],
                  minHeight: "4px",
                }}
              />
              <div className="text-xs text-slate-400 mt-2 transform -rotate-45 origin-left truncate max-w-16">
                {category}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
