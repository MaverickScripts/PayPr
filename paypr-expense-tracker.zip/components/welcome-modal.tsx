"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useState } from "react"
import { User, Target, DollarSign } from "lucide-react"

interface WelcomeModalProps {
  isOpen: boolean
  onClose: (userData: { name: string; monthlyBudget: number; savingsGoal: number }) => void
}

export function WelcomeModal({ isOpen, onClose }: WelcomeModalProps) {
  const [step, setStep] = useState(1)
  const [userData, setUserData] = useState({
    name: "",
    monthlyBudget: "",
    savingsGoal: "",
  })

  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1)
    } else {
      onClose({
        name: userData.name,
        monthlyBudget: Number.parseFloat(userData.monthlyBudget) || 2000,
        savingsGoal: Number.parseFloat(userData.savingsGoal) || 500,
      })
    }
  }

  const handleSkip = () => {
    onClose({
      name: "User",
      monthlyBudget: 2000,
      savingsGoal: 500,
    })
  }

  return (
    <Dialog open={isOpen} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md" hideClose>
        <DialogHeader>
          <DialogTitle className="text-center text-2xl font-bold">Welcome to PayPr</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Progress indicator */}
          <div className="flex justify-center space-x-2">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className={`w-2 h-2 rounded-full transition-colors ${i <= step ? "bg-blue-600" : "bg-gray-300"}`}
              />
            ))}
          </div>

          {step === 1 && (
            <div className="text-center space-y-4 animate-fade-in">
              <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto">
                <User className="w-8 h-8 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-xl font-semibold">What should we call you?</h3>
              <Input
                placeholder="Enter your name"
                value={userData.name}
                onChange={(e) => setUserData({ ...userData, name: e.target.value })}
                className="text-center"
              />
            </div>
          )}

          {step === 2 && (
            <div className="text-center space-y-4 animate-fade-in">
              <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto">
                <DollarSign className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-xl font-semibold">Set your spending limit</h3>
              <p className="text-gray-600 dark:text-gray-400">
                How much do you want to limit yourself to spend each month?
              </p>
              <Input
                type="number"
                placeholder="2000"
                value={userData.monthlyBudget}
                onChange={(e) => setUserData({ ...userData, monthlyBudget: e.target.value })}
                className="text-center"
              />
            </div>
          )}

          {step === 3 && (
            <div className="text-center space-y-4 animate-fade-in">
              <div className="w-16 h-16 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center mx-auto">
                <Target className="w-8 h-8 text-purple-600 dark:text-purple-400" />
              </div>
              <h3 className="text-xl font-semibold">Monthly savings target</h3>
              <p className="text-gray-600 dark:text-gray-400">
                How much would you like to save from your leftover budget?
              </p>
              <Input
                type="number"
                placeholder="500"
                value={userData.savingsGoal}
                onChange={(e) => setUserData({ ...userData, savingsGoal: e.target.value })}
                className="text-center"
              />
            </div>
          )}

          <div className="flex space-x-3">
            <Button variant="outline" onClick={handleSkip} className="flex-1 bg-transparent">
              Skip
            </Button>
            <Button onClick={handleNext} className="flex-1">
              {step === 3 ? "Get Started" : "Next"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
