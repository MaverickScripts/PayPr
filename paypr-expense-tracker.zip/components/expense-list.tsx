"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { MoreHorizontal, Edit, Trash2 } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface Expense {
  id: string
  amount: number
  category: string
  description: string
  date: string
  currency: string
}

interface ExpenseListProps {
  expenses: Expense[]
  currency: string
}

export function ExpenseList({ expenses, currency }: ExpenseListProps) {
  if (expenses.length === 0) {
    return (
      <div className="text-center py-16">
        <div className="w-20 h-20 bg-slate-700/50 rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-3xl">💸</span>
        </div>
        <h3 className="text-xl font-bold text-white mb-2">No expenses yet!</h3>
        <p className="text-slate-400 max-w-md mx-auto">
          Start tracking your expenses by adding your first transaction. Click the "Add Expense" button to get started.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {expenses.map((expense) => (
        <Card
          key={expense.id}
          className="p-4 bg-slate-700/30 dark:bg-slate-800/30 border border-slate-600/50 hover:shadow-lg hover:shadow-purple-500/10 transition-all duration-200 hover:scale-[1.02] hover:border-purple-500/30"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-slate-800 dark:bg-slate-700 rounded-xl flex items-center justify-center shadow-sm">
                <span className="text-2xl">
                  {expense.category === "Food" && "🍕"}
                  {expense.category === "Shopping" && "🛍️"}
                  {expense.category === "Subscriptions" && "📱"}
                  {expense.category === "Transport" && "🚗"}
                  {expense.category === "Entertainment" && "🎬"}
                  {expense.category === "Health" && "🏥"}
                  {expense.category === "Education" && "📚"}
                  {!["Food", "Shopping", "Subscriptions", "Transport", "Entertainment", "Health", "Education"].includes(
                    expense.category,
                  ) && "💰"}
                </span>
              </div>
              <div>
                <p className="font-bold text-white">{expense.description}</p>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge variant="secondary" className="text-xs bg-slate-600/50 text-slate-300 border-slate-500">
                    {expense.category}
                  </Badge>
                  <span className="text-sm text-slate-400">{new Date(expense.date).toLocaleDateString()}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <span className="font-black text-lg text-white">
                {currency}
                {expense.amount.toFixed(2)}
              </span>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="hover:bg-slate-600 text-slate-400 hover:text-white">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700">
                  <DropdownMenuItem className="text-white hover:bg-slate-700">
                    <Edit className="w-4 h-4 mr-2" />
                    Edit
                  </DropdownMenuItem>
                  <DropdownMenuItem className="text-red-400 hover:bg-slate-700">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}
