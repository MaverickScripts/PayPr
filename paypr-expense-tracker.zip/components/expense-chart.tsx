"use client"

import { useEffect, useState } from "react"

interface ExpenseChartProps {
  data: Record<string, number>
  type: "pie" | "bar"
  currency?: string
}

const COLORS = ["#3B82F6", "#8B5CF6", "#10B981", "#F59E0B", "#EF4444", "#6B7280", "#EC4899", "#14B8A6"]

export function ExpenseChart({ data, type, currency = "$" }: ExpenseChartProps) {
  const [isClient, setIsClient] = useState(false)
  const [RechartsComponents, setRechartsComponents] = useState<any>(null)

  useEffect(() => {
    setIsClient(true)

    // Dynamically import Recharts to avoid SSR issues
    const loadRecharts = async () => {
      try {
        const recharts = await import("recharts")
        setRechartsComponents(recharts)
      } catch (error) {
        console.error("Failed to load Recharts:", error)
      }
    }

    loadRecharts()
  }, [])

  console.log("ExpenseChart received data:", data, "type:", type)

  // Check if data exists and has values
  if (!data || typeof data !== "object") {
    console.log("No data provided to chart")
    return (
      <div className="h-[300px] flex items-center justify-center text-slate-500">
        <div className="text-center">
          <div className="text-4xl mb-2">📊</div>
          <p className="text-white">No data provided</p>
        </div>
      </div>
    )
  }

  // Convert data to chart format and filter out zero values
  const chartData = Object.entries(data)
    .filter(([category, amount]) => {
      console.log(`Processing ${category}: ${amount}`)
      return amount > 0
    })
    .map(([category, amount]) => ({
      category,
      amount: Number(amount),
      name: category,
      value: Number(amount), // For pie chart
    }))
    .sort((a, b) => b.amount - a.amount)

  console.log("Processed chart data:", chartData)

  if (chartData.length === 0) {
    return (
      <div className="h-[300px] flex items-center justify-center text-slate-500">
        <div className="text-center">
          <div className="text-4xl mb-2">📊</div>
          <p className="text-white">No data available</p>
          <p className="text-sm text-slate-400">Add some expenses to see charts</p>
        </div>
      </div>
    )
  }

  // Show loading state while Recharts is loading
  if (!isClient || !RechartsComponents) {
    return (
      <div className="h-[300px] flex items-center justify-center text-slate-500">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mb-2"></div>
          <p className="text-white">Loading chart...</p>
        </div>
      </div>
    )
  }

  const { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } =
    RechartsComponents

  if (type === "pie") {
    return (
      <div className="w-full h-[300px] bg-slate-900/20 rounded-lg p-2">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={chartData}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ name, percent }) => {
                if (percent < 0.05) return ""
                return `${name}: ${(percent * 100).toFixed(0)}%`
              }}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip
              formatter={(value: number) => [`${currency}${value.toFixed(2)}`, "Amount"]}
              contentStyle={{
                backgroundColor: "#1f2937",
                border: "1px solid #374151",
                borderRadius: "8px",
                color: "#f9fafb",
              }}
            />
            <Legend
              wrapperStyle={{ color: "#9ca3af", fontSize: "12px" }}
              formatter={(value) => <span style={{ color: "#9ca3af" }}>{value}</span>}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
    )
  }

  return (
    <div className="w-full h-[300px] bg-slate-900/20 rounded-lg p-2">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
          <XAxis
            dataKey="category"
            stroke="#9ca3af"
            fontSize={12}
            angle={-45}
            textAnchor="end"
            height={80}
            interval={0}
          />
          <YAxis stroke="#9ca3af" fontSize={12} tickFormatter={(value) => `${currency}${value}`} />
          <Tooltip
            formatter={(value: number) => [`${currency}${value.toFixed(2)}`, "Amount"]}
            contentStyle={{
              backgroundColor: "#1f2937",
              border: "1px solid #374151",
              borderRadius: "8px",
              color: "#f9fafb",
            }}
          />
          <Bar dataKey="amount" fill="#3B82F6" radius={[4, 4, 0, 0]} name="Spending" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
