"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { TrendingUp, CheckCircle, BarChart3 } from "lucide-react"
import { useState } from "react"

interface AbnormalSpendingAlertProps {
  isOpen: boolean
  onClose: () => void
  spendingData: {
    category: string
    currentAmount: number
    avgAmount: number
    description: string
  }
  currency: string
}

export function AbnormalSpendingAlert({ isOpen, onClose, spendingData, currency }: AbnormalSpendingAlertProps) {
  const [showInsights, setShowInsights] = useState(false)

  const percentageIncrease = ((spendingData.currentAmount - spendingData.avgAmount) / spendingData.avgAmount) * 100

  const handleGetInsights = () => {
    setShowInsights(true)
  }

  const handleDismiss = () => {
    onClose()
  }

  if (showInsights) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <BarChart3 className="w-5 h-5 text-blue-500" />
              <span>Spending Analysis</span>
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            <div className="text-center">
              <div className="text-4xl mb-2">📊</div>
              <h3 className="text-lg font-semibold mb-2">{spendingData.category} Spending Breakdown</h3>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-4 text-center">
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">This Month</p>
                <p className="text-2xl font-bold text-red-600 dark:text-red-400">
                  {currency}
                  {spendingData.currentAmount.toFixed(2)}
                </p>
              </div>
              <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 text-center">
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Average</p>
                <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {currency}
                  {spendingData.avgAmount.toFixed(2)}
                </p>
              </div>
            </div>

            <div className="bg-orange-50 dark:bg-orange-900/20 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                <TrendingUp className="w-5 h-5 text-orange-600" />
                <span className="font-semibold">{percentageIncrease.toFixed(0)}% higher than usual</span>
              </div>
              <p className="text-sm">
                You've spent {currency}
                {(spendingData.currentAmount - spendingData.avgAmount).toFixed(2)} more than your typical{" "}
                {spendingData.category.toLowerCase()} budget.
              </p>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
              <h4 className="font-semibold mb-2">Recommendations:</h4>
              <ul className="text-sm space-y-1">
                <li>• Review recent {spendingData.category.toLowerCase()} purchases</li>
                <li>• Set a weekly limit for this category</li>
                <li>• Consider if this was a one-time expense</li>
                <li>• Look for alternatives or discounts</li>
              </ul>
            </div>

            <Button onClick={onClose} className="w-full">
              Thanks for the insights!
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-orange-500" />
            <span>Unusual Spending Detected</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="text-center">
            <div className="text-4xl mb-2">💥</div>
            <h3 className="text-lg font-semibold mb-2">High {spendingData.category} Spending</h3>
            <p className="text-gray-600 dark:text-gray-300">{spendingData.description}</p>
          </div>

          <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 text-center">
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">This month you've spent</p>
            <p className="text-2xl font-bold">
              {currency}
              {spendingData.currentAmount.toFixed(2)}
            </p>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              vs. usual {currency}
              {spendingData.avgAmount.toFixed(2)}
            </p>
          </div>

          <div className="flex space-x-3">
            <Button onClick={handleDismiss} variant="outline" className="flex-1 bg-transparent">
              <CheckCircle className="w-4 h-4 mr-2" />
              Yes, I know
            </Button>
            <Button onClick={handleGetInsights} className="flex-1">
              <BarChart3 className="w-4 h-4 mr-2" />
              Get Insights
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
