"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useState } from "react"
import { Calendar, Target, DollarSign } from "lucide-react"

interface MonthlyResetModalProps {
  isOpen: boolean
  onClose: (userData: { monthlyBudget: number; savingsGoal: number }) => void
  currentUserData: { name: string; monthlyBudget: number; savingsGoal: number }
}

export function MonthlyResetModal({ isOpen, onClose, currentUserData }: MonthlyResetModalProps) {
  const [userData, setUserData] = useState({
    monthlyBudget: currentUserData.monthlyBudget.toString(),
    savingsGoal: currentUserData.savingsGoal.toString(),
  })

  const currentMonth = new Date().toLocaleDateString("en-US", { month: "long", year: "numeric" })

  const handleSubmit = () => {
    onClose({
      monthlyBudget: Number.parseFloat(userData.monthlyBudget) || currentUserData.monthlyBudget,
      savingsGoal: Number.parseFloat(userData.savingsGoal) || currentUserData.savingsGoal,
    })
  }

  const handleKeepSame = () => {
    onClose({
      monthlyBudget: currentUserData.monthlyBudget,
      savingsGoal: currentUserData.savingsGoal,
    })
  }

  return (
    <Dialog open={isOpen} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md" hideClose>
        <DialogHeader>
          <DialogTitle className="text-center text-2xl font-bold">New Month, Fresh Start! 🎉</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto">
              <Calendar className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold">Welcome to {currentMonth}!</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Your expenses have been reset for the new month. Would you like to update your budget goals?
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Monthly Budget</label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
                <Input
                  type="number"
                  placeholder={currentUserData.monthlyBudget.toString()}
                  value={userData.monthlyBudget}
                  onChange={(e) => setUserData({ ...userData, monthlyBudget: e.target.value })}
                  className="pl-10"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Savings Goal</label>
              <div className="relative">
                <Target className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
                <Input
                  type="number"
                  placeholder={currentUserData.savingsGoal.toString()}
                  value={userData.savingsGoal}
                  onChange={(e) => setUserData({ ...userData, savingsGoal: e.target.value })}
                  className="pl-10"
                />
              </div>
            </div>
          </div>

          <div className="flex space-x-3">
            <Button variant="outline" onClick={handleKeepSame} className="flex-1 bg-transparent">
              Keep Same
            </Button>
            <Button onClick={handleSubmit} className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600">
              Update Goals
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
