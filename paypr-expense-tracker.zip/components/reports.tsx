"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Download, TrendingUp, Calendar, PieChart, Brain, Menu, X } from "lucide-react"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"
import { SimpleChart } from "@/components/simple-chart"
import { ExpenseChart } from "@/components/expense-chart"

interface Expense {
  id: string
  amount: number
  category: string
  description: string
  date: string
  currency: string
}

export function Reports() {
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [timeRange, setTimeRange] = useState("month")
  const [insights, setInsights] = useState<string[]>([])
  const [isLoadingInsights, setIsLoadingInsights] = useState(false)
  const [isExporting, setIsExporting] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [currency, setCurrency] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("paypr-currency") || "$"
    }
    return "$"
  })

  useEffect(() => {
    fetchExpenses()
  }, [])

  useEffect(() => {
    if (expenses.length > 0) {
      generateInsights()
    }
  }, [expenses])

  const fetchExpenses = async () => {
    try {
      const response = await fetch("/api/expenses")
      const data = await response.json()
      console.log("Fetched expenses in reports:", data) // Debug log
      setExpenses(Array.isArray(data) ? data : [])
    } catch (error) {
      console.error("Failed to fetch expenses:", error)
      setExpenses([])
    }
  }

  const generateInsights = async () => {
    setIsLoadingInsights(true)
    try {
      const userData = JSON.parse(localStorage.getItem("paypr-user-data") || '{"monthlyBudget": 2000}')
      const totalSpent = expenses.reduce((sum, expense) => sum + expense.amount, 0)

      const response = await fetch("/api/insights", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          expenses,
          monthlyBudget: userData.monthlyBudget,
          totalSpent,
        }),
      })

      const data = await response.json()
      setInsights(data.insights)
    } catch (error) {
      console.error("Failed to generate insights:", error)
      setInsights([
        "Unable to generate AI insights at the moment",
        "Continue tracking expenses for better analysis",
        "Review your spending patterns manually",
        "Consider setting category-specific budgets",
      ])
    } finally {
      setIsLoadingInsights(false)
    }
  }

  const handleExport = async () => {
    setIsExporting(true)
    try {
      const userData = JSON.parse(
        localStorage.getItem("paypr-user-data") || '{"name": "User", "monthlyBudget": 2000, "savingsGoal": 500}',
      )
      const totalSpent = expenses.reduce((sum, expense) => sum + expense.amount, 0)
      const categoryTotals = expenses.reduce(
        (acc, expense) => {
          acc[expense.category] = (acc[expense.category] || 0) + expense.amount
          return acc
        },
        {} as Record<string, number>,
      )

      const response = await fetch("/api/export", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          expenses,
          userData,
          categoryTotals,
          totalSpent,
          currency, // Include the user's selected currency
        }),
      })

      const data = await response.json()

      const blob = new Blob([data.content], { type: "text/plain" })
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = data.filename
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
    } catch (error) {
      console.error("Export failed:", error)
    } finally {
      setIsExporting(false)
    }
  }

  // Calculate filtered expenses based on time range
  const getFilteredExpenses = () => {
    if (!Array.isArray(expenses) || expenses.length === 0) {
      console.log("No expenses to filter")
      return []
    }

    const now = new Date()
    const startDate = new Date()

    switch (timeRange) {
      case "week":
        startDate.setDate(now.getDate() - 7)
        break
      case "month":
        startDate.setMonth(now.getMonth() - 1)
        break
      case "quarter":
        startDate.setMonth(now.getMonth() - 3)
        break
      case "year":
        startDate.setFullYear(now.getFullYear() - 1)
        break
      default:
        startDate.setMonth(now.getMonth() - 1)
    }

    const filtered = expenses.filter((expense) => {
      const expenseDate = new Date(expense.date)
      return expenseDate >= startDate
    })

    console.log(`Filtered expenses for ${timeRange}:`, filtered)
    return filtered
  }

  const filteredExpenses = getFilteredExpenses()
  const totalSpent = filteredExpenses.reduce((sum, expense) => sum + expense.amount, 0)

  function getDaysInRange() {
    switch (timeRange) {
      case "week":
        return 7
      case "month":
        return 30
      case "quarter":
        return 90
      case "year":
        return 365
      default:
        return 30
    }
  }

  const avgDaily = filteredExpenses.length > 0 ? totalSpent / getDaysInRange() : 0

  // Process category data for pie chart
  const categoryData = filteredExpenses.reduce(
    (acc, expense) => {
      if (expense && expense.category && typeof expense.amount === "number") {
        acc[expense.category] = (acc[expense.category] || 0) + expense.amount
      }
      return acc
    },
    {} as Record<string, number>,
  )

  console.log("Category data for chart:", categoryData)

  // Process time-based data for bar chart
  const getTimeBasedData = () => {
    if (filteredExpenses.length === 0) return {}

    const timeData: Record<string, number> = {}

    filteredExpenses.forEach((expense) => {
      const date = new Date(expense.date)
      let key = ""

      switch (timeRange) {
        case "week":
          // Group by day for week view
          key = date.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })
          break
        case "month":
          // Group by week for month view
          const weekNumber = Math.ceil(date.getDate() / 7)
          key = `Week ${weekNumber}`
          break
        case "quarter":
          // Group by month for quarter view
          key = date.toLocaleDateString("en-US", { month: "short" })
          break
        case "year":
          // Group by month for year view
          key = date.toLocaleDateString("en-US", { month: "short", year: "2-digit" })
          break
        default:
          key = date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
      }

      timeData[key] = (timeData[key] || 0) + expense.amount
    })

    return timeData
  }

  const timeBasedData = getTimeBasedData()
  console.log("Time-based data for chart:", timeBasedData)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900/20 to-black dark:from-black dark:via-blue-950/30 dark:to-black">
      {/* Header */}
      <header className="bg-slate-900/80 dark:bg-black/80 backdrop-blur-xl border-b border-slate-800/50 dark:border-slate-700/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-3 sm:py-4">
            <div className="flex items-center space-x-2 sm:space-x-4">
              <Link href="/dashboard" className="hidden sm:block">
                <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white hover:bg-slate-800">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Dashboard
                </Button>
              </Link>
              <h1 className="text-lg sm:text-xl font-bold text-white">Reports & Analytics</h1>
            </div>
            <div className="flex items-center space-x-2 sm:space-x-4">
              <Button
                variant="outline"
                size="sm"
                onClick={handleExport}
                disabled={isExporting || expenses.length === 0}
                className="hidden sm:flex bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm border-slate-700 text-white hover:text-white font-bold"
              >
                <Download className="w-4 h-4 mr-2" />
                {isExporting ? "Exporting..." : "Export"}
              </Button>
              <ThemeToggle />

              {/* Mobile menu button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="sm:hidden p-2 rounded-lg bg-slate-800/50 text-white hover:bg-slate-700/50 transition-colors"
              >
                {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation Menu */}
          {mobileMenuOpen && (
            <div className="sm:hidden border-t border-slate-800/50 py-4 space-y-2">
              <Link href="/dashboard" className="block">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-white hover:bg-slate-800/50"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <Button
                variant="ghost"
                onClick={() => {
                  handleExport()
                  setMobileMenuOpen(false)
                }}
                disabled={isExporting || expenses.length === 0}
                className="w-full justify-start text-white hover:bg-slate-800/50"
              >
                <Download className="w-4 h-4 mr-2" />
                {isExporting ? "Exporting..." : "Export Data"}
              </Button>
            </div>
          )}
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 md:py-8">
        {/* Debug Information */}
        <div className="mb-4 p-4 bg-slate-800/30 rounded-lg text-xs text-slate-400">
          <p>
            Debug Info: Total expenses: {expenses.length}, Filtered: {filteredExpenses.length}
          </p>
          <p>
            Categories: {Object.keys(categoryData).length}, Time periods: {Object.keys(timeBasedData).length}
          </p>
          <p>
            Total spent: {currency}
            {totalSpent.toFixed(2)}
          </p>
        </div>

        {expenses.length === 0 ? (
          <div className="text-center py-12 sm:py-16">
            <div className="w-16 h-16 sm:w-20 sm:h-20 bg-slate-700/50 rounded-full flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="w-8 h-8 sm:w-10 sm:h-10 text-slate-400" />
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white mb-2">No Data to Analyze</h2>
            <p className="text-slate-400 mb-6 text-sm sm:text-base max-w-md mx-auto">
              Start adding expenses to see detailed reports and insights about your spending patterns.
            </p>
            <Link href="/dashboard">
              <Button className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:via-indigo-700 hover:to-purple-700 font-bold">
                Add Your First Expense
              </Button>
            </Link>
          </div>
        ) : (
          <>
            {/* Time Range Selector */}
            <div className="flex flex-wrap gap-2 mb-6 sm:mb-8">
              {["week", "month", "quarter", "year"].map((range) => (
                <Button
                  key={range}
                  variant={timeRange === range ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTimeRange(range)}
                  className={
                    timeRange !== range
                      ? "bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm border-slate-700 text-white hover:text-white text-xs sm:text-sm"
                      : "bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-0 font-bold text-xs sm:text-sm"
                  }
                >
                  {range.charAt(0).toUpperCase() + range.slice(1)}
                </Button>
              ))}
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6 mb-6 sm:mb-8">
              <Card className="bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 shadow-xl">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-slate-300">Total Spent</CardTitle>
                  <TrendingUp className="h-4 w-4 text-blue-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl sm:text-2xl font-bold text-white">
                    {currency}
                    {totalSpent.toFixed(2)}
                  </div>
                  <p className="text-xs text-slate-400">
                    {timeRange === "week"
                      ? "This week"
                      : timeRange === "month"
                        ? "This month"
                        : timeRange === "quarter"
                          ? "This quarter"
                          : "This year"}
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 shadow-xl">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-slate-300">Daily Average</CardTitle>
                  <Calendar className="h-4 w-4 text-blue-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl sm:text-2xl font-bold text-white">
                    {currency}
                    {avgDaily.toFixed(2)}
                  </div>
                  <p className="text-xs text-slate-400">Per day</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 shadow-xl">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-slate-300">Categories</CardTitle>
                  <PieChart className="h-4 w-4 text-blue-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl sm:text-2xl font-bold text-white">{Object.keys(categoryData).length}</div>
                  <p className="text-xs text-slate-400">Active categories</p>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8 mb-6 sm:mb-8">
              <Card className="bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-white text-base sm:text-lg">
                    Spending by Category
                    <span className="text-sm text-slate-400 ml-2">
                      ({Object.keys(categoryData).length} categories, {currency}
                      {Object.values(categoryData)
                        .reduce((a, b) => a + b, 0)
                        .toFixed(2)}{" "}
                      total)
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="relative">
                    <ExpenseChart data={categoryData} type="pie" currency={currency} />
                    {/* Fallback chart */}
                    <div className="absolute inset-0 opacity-0 hover:opacity-100 transition-opacity">
                      <SimpleChart data={categoryData} type="pie" currency={currency} />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-white text-base sm:text-lg">
                    {timeRange === "week"
                      ? "Daily Trend"
                      : timeRange === "month"
                        ? "Weekly Trend"
                        : timeRange === "quarter"
                          ? "Monthly Trend"
                          : "Monthly Trend"}
                    <span className="text-sm text-slate-400 ml-2">({Object.keys(timeBasedData).length} periods)</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="relative">
                    <ExpenseChart data={timeBasedData} type="bar" currency={currency} />
                    {/* Fallback chart */}
                    <div className="absolute inset-0 opacity-0 hover:opacity-100 transition-opacity">
                      <SimpleChart data={timeBasedData} type="bar" currency={currency} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* AI Insights */}
            <Card className="mb-6 sm:mb-8 bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-white">
                  <Brain className="w-5 h-5 text-blue-400" />
                  <span className="text-base sm:text-lg">AI Insights & Recommendations</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingInsights ? (
                  <div className="flex items-center justify-center py-6 sm:py-8">
                    <div className="w-6 h-6 sm:w-8 sm:h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                    <span className="ml-3 text-slate-400 text-sm sm:text-base">Generating AI insights...</span>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                    {insights.map((insight, index) => (
                      <div key={index} className="p-3 sm:p-4 bg-blue-900/20 rounded-xl border border-blue-700/50">
                        <p className="text-xs sm:text-sm text-blue-200">{insight}</p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Category Breakdown */}
            <Card className="bg-slate-800/50 dark:bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white text-base sm:text-lg">Category Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 sm:space-y-4">
                  {Object.entries(categoryData)
                    .sort(([, a], [, b]) => b - a)
                    .map(([category, amount]) => (
                      <div
                        key={category}
                        className="flex items-center justify-between p-3 sm:p-4 bg-slate-700/30 rounded-xl hover:bg-slate-700/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3 min-w-0 flex-1">
                          <span className="text-xl sm:text-2xl flex-shrink-0">
                            {category === "Food" && "🍕"}
                            {category === "Shopping" && "🛍️"}
                            {category === "Subscriptions" && "📱"}
                            {category === "Transport" && "🚗"}
                            {category === "Entertainment" && "🎬"}
                            {category === "Health" && "🏥"}
                            {category === "Education" && "📚"}
                            {![
                              "Food",
                              "Shopping",
                              "Subscriptions",
                              "Transport",
                              "Entertainment",
                              "Health",
                              "Education",
                            ].includes(category) && "💰"}
                          </span>
                          <span className="font-medium text-white text-sm sm:text-base truncate">{category}</span>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <p className="font-bold text-white text-sm sm:text-base">
                            {currency}
                            {amount.toFixed(2)}
                          </p>
                          <p className="text-xs sm:text-sm text-slate-400">
                            {totalSpent > 0 ? ((amount / totalSpent) * 100).toFixed(1) : 0}%
                          </p>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  )
}
