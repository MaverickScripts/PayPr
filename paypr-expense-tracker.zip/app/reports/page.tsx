import { Reports } from "@/components/reports"

export default function ReportsPage() {
  return <Reports />
}
