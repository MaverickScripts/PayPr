import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { name, email, role, message } = await request.json()

    // Log the contact form submission for analytics (optional)
    console.log("Contact form submission:", {
      name,
      email,
      role,
      message,
      timestamp: new Date().toISOString(),
    })

    // Since we're opening Gmail directly, we just return success
    return NextResponse.json({
      success: true,
      message: "Gmail opened successfully with your message!",
    })
  } catch (error) {
    console.error("Contact form error:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to process contact form. Please try again.",
      },
      { status: 500 },
    )
  }
}
