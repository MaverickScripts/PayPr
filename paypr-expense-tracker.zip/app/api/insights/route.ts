import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { expenses, monthlyBudget, totalSpent } = await request.json()

    if (!expenses || expenses.length === 0) {
      return NextResponse.json({
        insights: [
          "Start tracking your expenses to get personalized insights",
          "Set up your first expense to begin your financial journey",
          "Regular tracking helps identify spending patterns",
          "Consider setting weekly spending goals for better control",
        ],
      })
    }

    // Prepare data for analysis without external AI
    const categoryTotals = expenses.reduce((acc: any, expense: any) => {
      acc[expense.category] = (acc[expense.category] || 0) + expense.amount
      return acc
    }, {})

    const budgetUsage = (totalSpent / monthlyBudget) * 100
    const topCategory = Object.entries(categoryTotals).sort(([, a], [, b]) => (b as number) - (a as number))[0]
    const avgExpense = totalSpent / expenses.length

    // Generate insights based on spending patterns
    const insights = []

    if (budgetUsage > 80) {
      insights.push("You're using most of your budget - consider reducing discretionary spending")
    } else if (budgetUsage < 50) {
      insights.push("Great job staying under budget! Consider increasing your savings goal")
    } else {
      insights.push("You're on track with your budget - keep up the good work")
    }

    if (topCategory) {
      insights.push(`Your highest spending is on ${topCategory[0]} - review if this aligns with your priorities`)
    }

    if (avgExpense > 50) {
      insights.push("Your average expense is high - look for opportunities to reduce costs")
    } else {
      insights.push("You're making mostly small purchases - good for budget control")
    }

    const recentExpenses = expenses.slice(0, 5)
    const hasLargeExpenses = recentExpenses.some((exp: any) => exp.amount > avgExpense * 2)
    if (hasLargeExpenses) {
      insights.push("You have some large recent expenses - ensure they're necessary purchases")
    } else {
      insights.push("Your recent spending is consistent - great financial discipline")
    }

    return NextResponse.json({ insights: insights.slice(0, 4) })
  } catch (error) {
    console.error("Insights generation error:", error)
    return NextResponse.json({
      insights: [
        "Continue tracking expenses for better analysis",
        "Review your spending patterns weekly",
        "Set category-specific budgets for better control",
        "Consider the 50/30/20 budgeting rule for balance",
      ],
    })
  }
}
