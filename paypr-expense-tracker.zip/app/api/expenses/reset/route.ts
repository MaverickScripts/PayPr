import { NextResponse } from "next/server"

// Reset expenses for new month
const expenses: any[] = []

export async function POST() {
  expenses.length = 0 // Clear the expenses array
  return NextResponse.json({ success: true, message: "Expenses reset for new month" })
}

export async function GET() {
  return NextResponse.json({ expenses: expenses.length })
}
