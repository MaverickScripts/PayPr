import { NextResponse } from "next/server"

// Start with empty expenses - no mock data
const expenses: any[] = []

export async function GET() {
  return NextResponse.json(expenses)
}

export async function POST(request: Request) {
  const expense = await request.json()

  const newExpense = {
    id: Date.now().toString(),
    ...expense,
    date: new Date().toISOString(),
  }

  expenses.push(newExpense)
  return NextResponse.json(newExpense)
}
